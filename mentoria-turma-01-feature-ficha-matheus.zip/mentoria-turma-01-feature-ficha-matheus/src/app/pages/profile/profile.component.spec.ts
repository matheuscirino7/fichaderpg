import { AppModule } from './../../app.module';
import { PagesModule } from './../pages.module';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { of } from 'rxjs';

import { ProfileComponent } from './profile.component';
import { InformacoesService } from '../../shared/services/informacoes/informacoes.service';

describe('ProfileComponent', () => {
  let component: ProfileComponent;
  let fixture: ComponentFixture<ProfileComponent>;
  let routerSpy = { navigate: jasmine.createSpy('navigate')};
  const MockInformacoes = { getInformacoes: () => {
    return of([
      {
        "informacoes": {
            "atributos": [
                {
                "titulo": "🎤 Comunicação",
                "valor": 50
                },
                {
                "titulo": "🧠 Resolução de Problemas",
                "valor": 20
                },
                {
                "titulo": "🎨 Design",
                "valor": 10
                }
            ],
            "hobbies": [
                {
                "titulo": "🤑 Investimentos",
                "nota": 5
                },
                {
                "titulo": "🍹 Barzinho",
                "nota": 5
                },
                {
                "titulo": "🖥️ Games",
                "nota": 5
                },
                {
                "titulo": "🎬 Filmes",
                "nota": 3
                },
                {
                "titulo": "🎵 Músicas",
                "nota": 4
                }
            ],
            "pontosFortes": [
                {
                "titulo": "😎 Carisma",
                "nota": 3
                },
                {
                "titulo": "🤗 Empatia",
                "nota": 3
                },
                {
                "titulo": "💚 Humanidade",
                "nota": 3
                },
                {
                "titulo": "✔️ Assertividade",
                "nota": 3
                }
            ],
            "pontosFracos": [
                {
                "titulo": "💔 Ansiedade",
                "nota": 3
                },
                {
                "titulo": "💔 Insegurança",
                "nota": 3
                },
                {
                "titulo": "💔 Impaciência",
                "nota": 3
                }
            ],
            "curiosidades": [
                {
                "titulo": "🔴⚪⚫ São Paulino",
                "nota": 3
                },
                {
                "titulo": "🤑 Jovem investidor",
                "nota": 3
                },
                {
                "titulo": "🎮 Gamer",
                "nota": 3
                }
            ],
            "profile": {
                "nick": "hpkNTC",
                "clan": "Corretora de Seguros",
                "level": 5,
                "idade": 25,
                "altura": "1,70",
                "peso": 65,
                "descricao": "Possui alguma experiência com atendimento aos clientes, não acomodado decidiu se aventurar no novo mundo Front-end e luta bravamente para conseguir sobreviver utilizando suas poucas habilidades em Angular. Possui um hobbie muito útil considerando sua nacionalidade: Investimentos."
            }
        }
    }
    ])
  } }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [],
      imports: [ AppModule ],
      providers: [{provide: Router, useValue: routerSpy},
      {provide: InformacoesService, useValue: MockInformacoes}
    ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfileComponent);
    providers: [
      ProfileComponent
    ]
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getInformacoes', () => {
    spyOn(component,'getInformacoes').and.callThrough();
    component.getInformacoes();
    expect(component.getInformacoes).toHaveBeenCalledTimes(1)
  })

  it('should navigate to atributos', () => {
    component.onClickAtributosBtn()
    expect(routerSpy.navigate).toHaveBeenCalledWith(['atributos'])
  });

  it('should navigate to hobbies', () => {
    component.onClickHobbiesBtn()
    expect(routerSpy.navigate).toHaveBeenCalledWith(['hobbies'])
  });

  it('should navigate to pontos-fortes', () => {
    component.onClickFortesBtn()
    expect(routerSpy.navigate).toHaveBeenCalledWith(['pontos-fortes'])
  });

  it('should navigate to pontos-fracos', () => {
    component.onClickFracosBtn()
    expect(routerSpy.navigate).toHaveBeenCalledWith(['pontos-fracos'])
  });

  it('should navigate to curiosidades', () => {
    component.onClickCuriosidadesBtn()
    expect(routerSpy.navigate).toHaveBeenCalledWith(['curiosidades'])
  });
});
