import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DssButtonModule, DssIconModule, DssListModule, DssTypographyModule } from '@dss/components';
import { PagesRoutingModule } from './pages-routing.module';
import { DssBadgeModule } from '@dss/components/badge';
import { DssProgressLoaderModule } from '@dss/components/progress-loader';
import { DssSliderModule } from '@dss/components/slider';
import { HttpClientModule } from '@angular/common/http';
import { DssMenuModule } from '@dss/components/menu';
import { ProfileComponent } from './profile/profile.component';
import { AtributosComponent } from './atributos/atributos.component';
import { HobbiesComponent } from './hobbies/hobbies.component';
import { PontosFortesComponent } from './pontos-fortes/pontos-fortes.component';
import { CuriosidadesComponent } from './curiosidades/curiosidades.component';
import { LoadingComponent } from '../shared/components/loading/loading.component';
import { DssDialogModule } from '@dss/components/dialog';





@NgModule({
  declarations: [
    ProfileComponent,
    AtributosComponent,
    HobbiesComponent,
    PontosFortesComponent,
    PontosFortesComponent,
    CuriosidadesComponent,
    LoadingComponent
  ],
  imports: [
    CommonModule,
    PagesRoutingModule,
    FormsModule,
    DssBadgeModule,
    DssTypographyModule,
    DssProgressLoaderModule,
    DssButtonModule,
    DssSliderModule,
    DssListModule,
    DssIconModule,
    HttpClientModule,
    DssMenuModule,
    DssDialogModule
  ],
  providers: [ ],
})
export class PagesModule { }
