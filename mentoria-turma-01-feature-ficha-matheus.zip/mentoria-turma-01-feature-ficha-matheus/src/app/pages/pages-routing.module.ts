import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { ProfileComponent } from './profile/profile.component';
import { AtributosComponent } from './atributos/atributos.component';
import { HobbiesComponent } from './hobbies/hobbies.component';
import { PontosFortesComponent } from './pontos-fortes/pontos-fortes.component';
import { CuriosidadesComponent } from './curiosidades/curiosidades.component';


const routes: Routes = [
    {
        path: '',
        component: ProfileComponent
    },
    {
        path: 'atributos',
        component: AtributosComponent
    },
    {
        path: 'hobbies',
        component: HobbiesComponent
    },
    {
        path: 'pontos-fortes',
        component: PontosFortesComponent
    },
    {
        path: 'pontos-fracos',
        component: PontosFortesComponent
    },
    {
        path: 'curiosidades',
        component: CuriosidadesComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
    providers: [],
})

export class PagesRoutingModule {

}
