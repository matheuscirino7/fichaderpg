import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { delay } from 'rxjs/operators'
import { IInformacoes } from 'src/app/shared/models/informacoes.model';
import { InformacoesService } from '../../shared/services/informacoes/informacoes.service';
import { ApplicationRoutes } from '../../shared/steps/steps.helper';


@Component({
  selector: 'app-atributos',
  templateUrl: './atributos.component.html',
  styleUrls: ['./atributos.component.scss']
})
export class AtributosComponent implements OnInit {

  informacoes!: IInformacoes;
  loading: boolean = true;
  public expanded = false;


  constructor(
    private router: Router,
    private informacoesService: InformacoesService
  ) { }

  ngOnInit(): void {
    this.getInformacoes()
  }

  onClickBackBtn() {
    this.router.navigate([ApplicationRoutes.PROFILE]);
  }

  getInformacoes() {
    this.informacoesService.getInformacoes().pipe(delay(1800)).subscribe((x)=>{
    this.informacoes=x;
    this.loading = false;
   })
  }

  onClickAtributosBtn() {
    this.router.navigate([ApplicationRoutes.ATRIBUTOS]);
  }

  onClickHobbiesBtn(){
    this.router.navigate([ApplicationRoutes.HOBBIES]);
  }

  onClickFortesBtn(){
    this.router.navigate([ApplicationRoutes.FORTES]);
  }

  onClickFracosBtn(){
    this.router.navigate([ApplicationRoutes.FRACOS]);
  }

  onClickCuriosidadesBtn(){
    this.router.navigate([ApplicationRoutes.CURIOSIDADES]);
  }
}
