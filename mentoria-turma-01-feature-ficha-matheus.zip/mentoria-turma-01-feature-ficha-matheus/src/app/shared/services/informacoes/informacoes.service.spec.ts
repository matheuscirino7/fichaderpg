import { HttpClientModule } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';

import { InformacoesService } from './informacoes.service';

describe('InformacoesService', () => {
  let service: InformacoesService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [],
      imports: [HttpClientModule],
    });
    service = TestBed.inject(InformacoesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get informacoes', () => {
    spyOn(service, 'getInformacoes').and.callThrough();
    service.getInformacoes();
    expect(service.getInformacoes).toHaveBeenCalledTimes(1);
  });
});
