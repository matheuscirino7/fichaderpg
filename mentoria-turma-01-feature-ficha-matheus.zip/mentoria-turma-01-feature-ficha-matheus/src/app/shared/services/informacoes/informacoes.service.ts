import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class InformacoesService {
  url: string = 'http://localhost:3000/informacoes'
 
     constructor(private http: HttpClient) { }
 
     getInformacoes(): Observable<any> {
         return this.http.get(this.url)
     }
 }
