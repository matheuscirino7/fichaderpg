export interface IInformacoes {
            atributos: Array<
                {
                titulo: string,
                valor: number
                }
            >,
            hobbies: Array<
                {
                    titulo: string,
                    nota: number
                }
            >,
            pontosFortes: Array<
                {
                    titulo: string,
                    nota: number
                }
            >,
            pontosFracos: Array<
                {
                    titulo: string,
                    nota: number
                }
            >,
            curiosidades: Array<
                {
                    titulo: string,
                    nota: number
                }
            >,
            profile: {
                nick: string,
                clan: string,
                level: number,
                idade: number,
                altura: number,
                peso: number,
                descricao: string
            }
        }
    
