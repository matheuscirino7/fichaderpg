export class ApplicationRoutes {
    static ROOT = '';
    static PROFILE = 'profile';
    static ATRIBUTOS = 'atributos';
    static HOBBIES = 'hobbies';
    static FORTES = 'pontos-fortes';
    static FRACOS = 'pontos-fracos';
    static CURIOSIDADES = 'curiosidades';
  }