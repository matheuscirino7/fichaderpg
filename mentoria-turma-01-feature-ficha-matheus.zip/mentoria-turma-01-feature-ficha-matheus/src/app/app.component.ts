import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ApplicationRoutes } from './shared/steps/steps.helper';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'ficha-de-rpg';

  constructor(
    private route: Router,
  ) {}

  ngOnInit() {
    this.route.navigate([ApplicationRoutes.ROOT])
  }
}
