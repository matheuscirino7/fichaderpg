module.exports = {
    preset: 'jest-preset-angular',
    setupFilesAfterEnv: ['<rootDir>/setup-jest.ts'],
    testRunner: "jasmine2",
    globalSetup: 'jest-preset-angular/global-setup',
    testEnvironment: "jsdom",
    coverageProvider: "v8",
    coverageDirectory: "coverage",
    collectCoverage: true,
    clearMocks: true,
    transformIgnorePatterns: [
      'node_modules/(?!@afe|crypto-es)'],
  };